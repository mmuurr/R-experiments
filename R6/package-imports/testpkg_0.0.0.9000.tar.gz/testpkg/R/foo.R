Foo <-
  R6::R6Class("Foo",
    public = list(
      bar = function() tibble::tibble
    )
)
